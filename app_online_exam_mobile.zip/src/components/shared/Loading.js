import { React } from 'react'

export const Loading = () => 

    /*

    <div className="loader">
            <div className="loader-gif">
                <span></span>
            </div>
        </div>

    */
    <Text>Loading...</Text>
