
function Footer(){

    return (
        <div>
          <footer class="footer-area">
              <div class="container">
                <div class="row">
                  <div class="col-md-12">
                    <div class="copyright-text">
                    <img alt="adbanner" src="https://images.pexels.com/photos/139309/pexels-photo-139309.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940"></img>
                    </div>

                  
                  </div>
                </div>
              </div>
            
          </footer>
        </div>
    );
}

export default Footer;